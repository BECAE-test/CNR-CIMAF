import subprocess
import os
import sys
import re
import tkinter as tk
from tkinter import messagebox, ttk, Tk, Toplevel, Button, Label


def question_gui_biased():

    root = Tk()
    root.withdraw()
    
    def run_unbiased():
        top.destroy()
        root.quit()
        command_list2_part2()

    def run_unbiased_and_biased():
        top.destroy()
        root.quit()
        command_list2_part2()
        command_list3_part2()


    top = Toplevel()
    top.title("Select Search")

    Label(top, text="Would you like to run only the unbiased search, or both the unbiased and biased searches?").pack(padx=20, pady=10)

    Button(top, text="Only Unbiased", command=run_unbiased).pack(padx=10, pady=5)
    Button(top, text="Unbiased e Biased", command=run_unbiased_and_biased).pack(padx=10, pady=5)

    top.mainloop()
        

def command_list2_part2():
    try:
        compile_identify_pures = ["chmod", "a+x", "021_identify_pures"]
        run_identify_pures = ["./021_identify_pures"]
        compile_022_take = ["gfortran", "-o", "022_take.x", "022_take.f90"]
        run_022_take = ["./022_take.x"]
        run_023_copy = ["./023_copy.sh"]
        compile_search_unbiasedREV = ["chmod", "a+x", "024_search_unbiased.REVISE"]
        run_search_unbiasedREV = ["./024_search_unbiased.REVISE"]
        compile_02_best = ["gfortran", "-o", "02_best.x", "02_best.f90"]
        compile_03_take = ["gfortran", "-o", "03_take.x", "03_take.f90"]
        run_02_best = ["./02_best.x"]
        run_03_take = ["./03_take.x"]
        run_04_extract = ["./04_extract.sh"]
        # Avvia il processo SENZA &, in modo che Python lo gestisca direttamente
        base_dir = os.getcwd()
        with open(os.path.join(base_dir, "LOG_U"), "w") as log_file:
            process01 = subprocess.Popen(
                ["nohup", "./01_search_unbiased"],
                cwd=base_dir,
                stdin=subprocess.DEVNULL,
                stdout=log_file,
                stderr=subprocess.STDOUT
            )

        # Aspetta la terminazione effettiva del processo
        process01.wait()

        print("🔹 End 01_search_unbiased")
        print("🔹 Running 021_identify_pures ...")
        with open(os.devnull, "w") as DEVNULL:
            subprocess.run(compile_identify_pures, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)
            subprocess.run(run_identify_pures, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)
        print("🔹 Running 022_take ...")
        subprocess.run(compile_022_take, cwd=base_dir, check=True)
        subprocess.run(run_022_take, cwd=base_dir, check=True)
        print("🔹 Running 023_copy.sh ...")
        subprocess.run(run_023_copy, cwd=base_dir, check=True)
        print("🔹 Running 024_search_unbiased.REVISE ...")
        subprocess.run(compile_search_unbiasedREV, cwd=base_dir, check=True)
       # subprocess.run(run_search_unbiasedREV, cwd=base_dir, check=True)
        with open(os.devnull, "w") as DEVNULL:
            subprocess.run(run_search_unbiasedREV, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)

            print("🔹 Running 02_best ...")
            subprocess.run(compile_02_best, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)
            subprocess.run(run_02_best, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)
            print("🔹 Running 03_take ...")
            subprocess.run(compile_03_take, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)
            subprocess.run(run_03_take, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)
            print("🔹 Running 04_extract.sh ...")
            subprocess.run(run_04_extract, cwd=base_dir, check=True)

        print("✅ End script2!")

    except subprocess.CalledProcessError as e:
        print(f"❌ Error while executing a command: {e}")
        sys.exit(1)
    except FileNotFoundError as e:
        print(f"❌ Error: File or directory not found: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)





def command_list3_part2():

    run_best = ["./06_best.x"]
    run_take = ["./07_take.x"]
    run_extract = ["./08_extract.sh"]
    
    # Avvia il processo SENZA &, in modo che Python lo gestisca direttamente
    base_dir = os.getcwd()
    with open(os.path.join(base_dir, "LOG_U"), "w") as log_file:
        process05 = subprocess.Popen(
            ["nohup", "./05_search_biased"],
            cwd=base_dir,
            stdin=subprocess.DEVNULL,
            stdout=log_file,
            stderr=subprocess.STDOUT
        )

    # Aspetta la terminazione effettiva del processo
    process05.wait()

    print("🔹 End 05_search_biased")

    print("🔹 Running 06_best.x ...")
    with open(os.devnull, "w") as DEVNULL:
        subprocess.run(run_best, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)
        print("🔹 Running 07_take.x ...")
        subprocess.run(run_take, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)
        print("🔹 Running 08_extract.sh ...")
        subprocess.run(run_extract, cwd=base_dir, check=True, stdout=DEVNULL, stderr=DEVNULL)
    
    print("🔹 Fine script BIASED ...")

if __name__ == "__main__":
    question_gui_biased()
