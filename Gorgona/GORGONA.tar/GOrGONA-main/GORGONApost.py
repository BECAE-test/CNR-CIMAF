import pandas as pd
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import ttk, filedialog
from tkinter import messagebox
import PIL.ImageTk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
import os
import itertools
import subprocess

# Creazione della finestra di input
input_root = tk.Tk()
input_root.title("Insert parameters")

tk.Label(input_root, text="Choose the composition range to plot:\n").grid(row=0, column=0, columnspan=2, sticky="nsew")
tk.Label(input_root, text="From ... atoms of Type 1:").grid(row=2, column=0)
tk.Label(input_root, text="To ... atoms of Type 1:").grid(row=3, column=0)
tk.Label(input_root, text="Pruning (≥ of that used in Biased search):").grid(row=4, column=0)
tk.Label(input_root, text="Select Directory:").grid(row=5, column=0)

SizeStart_entry = tk.Entry(input_root)
SizeEnd_entry = tk.Entry(input_root)
Pruning_entry = tk.Entry(input_root)

directory_var = tk.StringVar()
directory_entry = tk.Entry(input_root, textvariable=directory_var, width=40)

def select_directory():
    directory = filedialog.askdirectory()
    directory_var.set(directory)

directory_button = tk.Button(input_root, text="Browse", command=select_directory)

SizeStart_entry.grid(row=2, column=1)
SizeEnd_entry.grid(row=3, column=1)
Pruning_entry.grid(row=4, column=1)
directory_entry.grid(row=5, column=1)
directory_button.grid(row=5, column=2)


def main_application():
    global root, canvas, fig, ax, curve_vars, plot_lines, curve_colors, select_all_var, point_labels
    
    root = tk.Tk()
    root.title("Curve Plot Selector")
    root.geometry("1600x900")

    def on_close():
        root.quit()
        root.destroy()
        os._exit(0)

    root.protocol("WM_DELETE_WINDOW", on_close)

    fig, ax = plt.subplots()
    fig.subplots_adjust(left=0.07, right=0.83)
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    toolbar = NavigationToolbar2Tk(canvas, root)
    toolbar.update()
    toolbar.pack(side=tk.TOP, fill=tk.X)

    curve_vars = {}
    plot_lines = {}
    curve_colors = {}
    color_cycle = itertools.cycle(plt.cm.tab10.colors)
    point_labels = {}

    def update_plot():
        ax.clear()
        ax.set_xlabel("Type 1 (%)")
        ax.set_ylabel("Excess Energy (eV)")
        #ax.set_title("Curve Plot")
        ax.grid(True, linestyle='--', alpha=0.6)

        for key, df in data.items():
            if curve_vars[key].get():
                if key not in curve_colors:
                    curve_colors[key] = next(color_cycle)
               # line, = ax.plot(df["x"].to_numpy(), df["y"].to_numpy(), marker='o', linestyle='-', label=f"Motif found at {key}", color=curve_colors[key])
                line, = ax.plot(df["x"].to_numpy(), df["y"].to_numpy(), marker='o', linestyle='-', label=f"Motif found at ({key},{SizeEnd - key})" if isinstance(key, int) else key, color=curve_colors[key])
                plot_lines[key] = line

        ax.legend(loc='upper left', bbox_to_anchor=(1, 1))
        canvas.draw()

        if not all(var.get() for var in curve_vars.values()):
            select_all_var.set(False)

    def toggle_all():
        state = select_all_var.get()
        for key in curve_vars:
            curve_vars[key].set(state)
        update_plot()

    frame = tk.Frame(root)
    frame.pack(side=tk.LEFT, fill=tk.Y)

    label = tk.Label(frame, text="Select Curve:")
    label.pack()

    select_all_var = tk.BooleanVar()
    select_all_chk = tk.Checkbutton(frame, text="Select all", variable=select_all_var, command=toggle_all)
    select_all_chk.pack()

    num_cols = 40
    row_frame = None
    for idx, key in enumerate(data.keys()):
        if idx % num_cols == 0:
            row_frame = tk.Frame(frame)
            row_frame.pack()

        var = tk.BooleanVar()
        curve_vars[key] = var
       # chk_test = "Envelope" if key == "result.out" else key
        chk = tk.Checkbutton(row_frame, text=f"{key}", variable=var, command=update_plot)
        chk.pack(side=tk.LEFT)

    
    def on_click(event):
        if event.inaxes is not None:
            min_dist = float("inf")
            closest_point = None
            closest_key = None
            closest_file = None
            closest_x = None
            closest_y = None
            closest_col3 = None 
            closest_col6 = None 

            for key, df in data.items():
               # if curve_vars[key].get():
                if key == "Envelope" or (key in curve_vars and curve_vars[key].get()): 
                    for i, (x, y) in enumerate(zip(df["x"], df["y"])):
                        dist = ((event.xdata - x) ** 2 + (event.ydata - y) ** 2) ** 0.5
                        if dist < min_dist and dist < 0.5:
                            min_dist = dist
                            closest_point = (x, y)
                            closest_key = key
                            closest_file = df["file"].iloc[i]
                            closest_x = df["x"].iloc[i]
                            closest_y = df["y"].iloc[i]
                            closest_col3 = df["col3"].iloc[i]
                            closest_col6 = df["col6"].iloc[i]    

            if closest_point:
                x, y = closest_point
                yyyy = f"{closest_key:04d}" if closest_key != "Envelope" else "Envelope"
               # yyyy = f"{closest_key:04d}"
                aaaa = x*SizeEnd/100
                aaaa = f"{round(aaaa):04d}"
                yyyy_Env = f"{int(closest_col6):04d}"
                
                filepath = os.path.join(directory, f"motifs/{yyyy}/run_{aaaa}/{closest_file}") if closest_key != "Envelope" else os.path.join(directory, f"motifs/{yyyy_Env}/run_{aaaa}/{closest_file}")
               # filepath = os.path.join(directory, f"motifs/{yyyy}/run_{aaaa}/{closest_file}")

                # **Se il popup per questo punto esiste già, chiudilo e rimuovilo**
                if (x, y) in point_labels:
                    point_labels[(x, y)].destroy()
                    del point_labels[(x, y)]
                    return  # Esci senza creare una nuova finestra

                # **Crea una nuova finestra per il pulsante**
                popup = tk.Toplevel(root)
                popup.title("Info")
                popup.attributes('-topmost', True)

                # Converti le coordinate del punto dal grafico allo schermo
                screen_x, screen_y = canvas.get_tk_widget().winfo_rootx(), canvas.get_tk_widget().winfo_rooty()
                point_screen_x, point_screen_y = ax.transData.transform((x, y))

                # Calcola la posizione del popup vicino al punto cliccato
                popup_x = int(screen_x + point_screen_x + 10)  # Offset a destra
                popup_y = int(screen_y + point_screen_y - 10)  # Offset sopra il punto per non coprirlo
                popup.geometry(f"+{popup_x}+{popup_y}")


                label = tk.Label(popup, text=f"Motif found at ({closest_col6},{SizeEnd-closest_col6})\n\nComposition: {closest_x:.2f}% of Type 1\n\nExcess Energy (eV): {closest_y}\n\nDescriptor: {closest_col3}\n")
                label.pack()

                def open_molden():
                    subprocess.Popen(["molden", filepath])
                    print(filepath)

                def open_xcrysden():
                    subprocess.Popen(["xcrysden","--xyz", filepath])
                    print(filepath)

                def open_jmol():
                    subprocess.Popen(["jmol", filepath])
                    print(filepath)

                button_molden = tk.Button(popup, text="Open with Molden", command=open_molden)
                button_molden.pack()

                button_xcry = tk.Button(popup, text="Open with Xcrysden", command=open_xcrysden)
                button_xcry.pack()

                button_jmol = tk.Button(popup, text="Open with Jmol", command=open_jmol)
                button_jmol.pack()

                # **Memorizza il popup nel dizionario per poterlo chiudere al secondo click**
                point_labels[(x, y)] = popup





    fig.canvas.mpl_connect('button_press_event', on_click)
    root.mainloop()





def start_application():
    global SizeStart, SizeEnd, Pruning, directory, data
    SizeStart = int(SizeStart_entry.get())
    SizeEnd = int(SizeEnd_entry.get())
    Pruning = int(Pruning_entry.get())
    directory = directory_var.get()
    input_root.destroy()

    # Leggi i file e memorizza i dati
    data = {}
   # data_ax = {}
    for i in range(SizeStart, SizeEnd + Pruning, Pruning):
        filename = f"curve-motif-{i:04d}.dat"
        filepath = os.path.join(directory, filename)
        if os.path.exists(filepath):
            df = pd.read_csv(filepath, sep=r"\s+", header=None, 
                             names=["x", "y", "col3", "col4", "col5", "col6", "file"], engine="python")
           # df_ax = pd.read_csv(filepath, sep=r"\s+", header=None, 
           #                  names=["x", "y", "col3", "col4", "col5", "col6", "file"], engine="python")
            df["x"] = (df["x"] / SizeEnd) * 100  # Converti x in percentuale
           
            data[i] = df
           # data_ax[i] = df_ax

    # Lettura del file result.out se esiste
    result_filepath = os.path.join(directory, "result.out")
    if os.path.exists(result_filepath):
        df_result = pd.read_csv(result_filepath, sep=r"\s+", header=None, 
                                names=["x", "y", "col3", "col4", "col5", "col6", "file"], engine="python")
        df_result["x"] = (df_result["x"] / SizeEnd) * 100  # Converti x in percentuale
        data["Envelope"] = df_result  # Aggiungi il file result.out con una chiave specifica

    main_application()

tk.Button(input_root, text="Start", command=start_application).grid(row=6, columnspan=2)
input_root.mainloop()


