#!/bin/bash

# Check if PyInstaller is installed
if ! command -v pyinstaller &> /dev/null; then
    echo "[✖] Error: PyInstaller is not installed. Please install it using 'pip3 install pyinstaller'."
    exit 1
fi

# Check if GORGONAzero_due.py exists in the current directory
if [[ ! -f "GORGONAzero_due.py" ]]; then
    echo "[✖] Error: File 'GORGONAzero_due.py' not found in the current directory."
    exit 1
fi

# Compile the Python script into a single executable file
pyinstaller --onefile --windowed GORGONAzero_due.py

# Check if the compilation was successful
if [[ -f "dist/GORGONAzero_due" || -f "dist/GORGONAzero_due.exe" ]]; then
    echo "[✔] Compilation successful!"
else
    echo "[✖] Error: Compilation failed. Check PyInstaller logs for details."
fi

mv ./dist/GORGONAzero_due ./

rm -rf build/ dist/

rm GORGONAzero_due.spec
