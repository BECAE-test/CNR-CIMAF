#!/bin/bash

# Check if PyInstaller is installed
if ! command -v pyinstaller &> /dev/null; then
    echo "[✖] Error: PyInstaller is not installed. Please install it using 'pip3 install pyinstaller'."
    exit 1
fi

# Check if graficoGORG.py exists in the current directory
if [[ ! -f "graficoGORG.py" ]]; then
    echo "[✖] Error: File 'graficoGORG.py' not found in the current directory."
    exit 1
fi

# Compile the Python script into a single executable file
pyinstaller --clean --onefile --windowed --hidden-import=PIL --hidden-import=tkinter --hidden-import=numpy --hidden-import=matplotlib --hidden-import=PIL.ImageTk --hidden-import=PIL._tkinter_finder graficoGORG.py

# Check if the compilation was successful
if [[ -f "dist/graficoGORG" || -f "dist/graficoGORG.exe" ]]; then
    echo "[✔] Compilation successful!"
else
    echo "[✖] Error: Compilation failed. Check PyInstaller logs for details."
fi

mv ./dist/graficoGORG ./

rm -rf build/ dist/

#rm graficoGORG.spec
