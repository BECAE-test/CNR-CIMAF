#!/bin/bash

# Array per memorizzare i messaggi di output
OUTPUT_MESSAGES=()


# Funzione per controllare e reinstallare Pillow nella giusta posizione
fix_pillow_installation() {
    PILLOW_PATH=$(python3 -c "import PIL; print(PIL.__file__)" 2>/dev/null || echo "not_installed")

    if [[ "$PILLOW_PATH" == *"/usr/lib/python3"* ]]; then
        OUTPUT_MESSAGES+=("[⚠] Pillow è installato in /usr/lib/python3/ ma potrebbe non funzionare con PyInstaller.")
        OUTPUT_MESSAGES+=("[+] Reinstallazione di Pillow nel percorso corretto...")

        # Rimuove la versione di sistema di Pillow e installa la versione pip
        sudo apt remove -y python3-pil
        pip3 install --no-cache-dir --upgrade pillow
    fi
}


# Funzione per controllare e installare i pacchetti
check_install() {
    PACKAGE_NAME=$1
    COMMAND_TO_CHECK=$2
    INSTALL_COMMAND=$3
    CHECK_METHOD=$4

    if [[ "$CHECK_METHOD" == "command" ]]; then
        if command -v $COMMAND_TO_CHECK &> /dev/null; then
            OUTPUT_MESSAGES+=("[✔] $PACKAGE_NAME è già installato.")
        else
            OUTPUT_MESSAGES+=("[+] Installazione di $PACKAGE_NAME in corso...")
            eval $INSTALL_COMMAND
            if command -v $COMMAND_TO_CHECK &> /dev/null; then
                OUTPUT_MESSAGES+=("[✔] $PACKAGE_NAME installato con successo!")
            else
                OUTPUT_MESSAGES+=("[✖] Errore: $PACKAGE_NAME non installato.")
            fi
        fi
    elif [[ "$CHECK_METHOD" == "dpkg" ]]; then
        if dpkg -s "$COMMAND_TO_CHECK" &> /dev/null; then
            OUTPUT_MESSAGES+=("[✔] $PACKAGE_NAME è già installato.")
        else
            OUTPUT_MESSAGES+=("[+] Installazione di $PACKAGE_NAME in corso...")
            eval $INSTALL_COMMAND
            if dpkg -s "$COMMAND_TO_CHECK" &> /dev/null; then
                OUTPUT_MESSAGES+=("[✔] $PACKAGE_NAME installato con successo!")
            else
                OUTPUT_MESSAGES+=("[✖] Errore: $PACKAGE_NAME non installato.")
            fi
        fi
    elif [[ "$CHECK_METHOD" == "python" ]]; then
        if python3 -c "import $COMMAND_TO_CHECK" &>/dev/null; then
            OUTPUT_MESSAGES+=("[✔] $PACKAGE_NAME è già installato.")
        else
            OUTPUT_MESSAGES+=("[+] Installazione di $PACKAGE_NAME in corso...")
            eval $INSTALL_COMMAND
            if python3 -c "import $COMMAND_TO_CHECK" &>/dev/null; then
                OUTPUT_MESSAGES+=("[✔] $PACKAGE_NAME installato con successo!")
            else
                OUTPUT_MESSAGES+=("[✖] Errore: $PACKAGE_NAME non installato.")
            fi
        fi
    fi
}

# **1. Correggere pacchetti bloccati**
OUTPUT_MESSAGES+=("[+] Correzione pacchetti bloccati...")
sudo apt --fix-broken install -y

# **2. Aggiornare il sistema**
OUTPUT_MESSAGES+=("[+] Aggiornamento del sistema...")
sudo apt update -y && sudo apt upgrade -y
sudo apt autoremove -y
sudo apt clean

# **3. Installare dipendenze mancanti**
OUTPUT_MESSAGES+=("[+] Installazione dipendenze base...")
sudo apt install -y python3 python3-pip python3-distutils python3-setuptools python3-wheel build-essential python3-dev

# **4. Correggere Pillow se installato nel percorso sbagliato**
fix_pillow_installation

# **4. Installare i pacchetti richiesti**
check_install "Python3" "python3" "sudo apt install -y python3" "command"
check_install "PIP3" "pip3" "sudo apt install -y python3-pip" "command"
check_install "PyInstaller" "pyinstaller" "sudo pip3 install pyinstaller" "command"
check_install "Tkinter" "python3-tk" "sudo apt install -y python3-tk" "dpkg"
check_install "GFortran" "gfortran" "sudo apt install -y gfortran" "command"
check_install "LAPACK Library" "liblapack-dev" "sudo apt install -y liblapack-dev" "dpkg"
check_install "FFTW3 Library" "libfftw3-dev" "sudo apt install -y libfftw3-dev" "dpkg"
check_install "Pandas" "pandas" "sudo pip3 install pandas" "python"
check_install "Matplotlib" "matplotlib" "sudo pip3 install matplotlib" "python"
check_install "Pillow" "PIL" "sudo pip3 install -y pillow" "python"

# **5. Controllare se pip3 è disponibile e sistemare PATH**
if ! command -v pip3 &> /dev/null; then
    OUTPUT_MESSAGES+=("[✖] pip3 non trovato, aggiungo alla PATH...")
    export PATH=$PATH:~/.local/bin
    source ~/.bashrc
fi

# Stampare tutti i messaggi alla fine
for MESSAGE in "${OUTPUT_MESSAGES[@]}"; do
    echo "$MESSAGE"
done

echo "[✔] Installazione completata con successo!"

