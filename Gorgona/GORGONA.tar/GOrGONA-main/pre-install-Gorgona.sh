#!/bin/bash

sudo apt install -y python3
sudo apt install -y python3-tk
sudo apt install -y gfortran
sudo apt install -y make
sudo apt install -y python3-pip
pip3 install pandas
pip3 install matplotlib
sudo apt install -y python3-matplotlib
