import subprocess
import os
import sys
import re
import tkinter as tk
from tkinter import messagebox, ttk

# ✅ Funzione per compilare il file bh_v07 e lo copia nelle cartelle parallel_unseeded_XxYy e parallel_seeded_XxYy
def esegui_make_e_copia():

    try:
        print("🔹 Start script...")

        # Definizione delle cartelle
        base_dir = os.getcwd()  # Prende la cartella corrente
        eam_dir = os.path.join(base_dir, "EAM-INTERNAL")
        target_dir = os.path.join(base_dir, "parallel_unseeded_XxYy")
        target_dir2 = os.path.join(base_dir, "parallel_seeded_XxYy")
        file_to_copy = "bh_v07"  # File da copiare

        # 🔹 Eseguire make dalla cartella EAM-INTERNAL
        print("🔹 Executing 'make' in EAM-INTERNAL...")
        subprocess.run(["make"], cwd=eam_dir, check=True)

        # 🔹 Copiare il file bh_v07 nelle cartelle parallel_unseeded_XxYy parallel_seeded_XxYy
        source_file = os.path.join(eam_dir, file_to_copy)

        if not os.path.exists(source_file):
            print(f"❌ Error: The file {file_to_copy} does not exist in {eam_dir}.")
            sys.exit(1)

        destination_file = os.path.join(target_dir, file_to_copy)
        destination_file2 = os.path.join(target_dir2, file_to_copy)

        print(f"🔹 Copying {file_to_copy} in {target_dir}...")
        subprocess.run(["cp", source_file, destination_file], check=True)

        print(f"🔹 Copying {file_to_copy} in {target_dir2}...")
        subprocess.run(["cp", source_file, destination_file2], check=True)

        print("✅ End script!")

    except subprocess.CalledProcessError as e:
        print(f"❌ Error while executing a command: {e}")
        sys.exit(1)
    except FileNotFoundError as e:
        print(f"❌ Error: File or directory not found: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

# ✅ Funzione per ottenere le coppie di elementi da database_ff
def carica_elementi_da_database():

    database_dir = os.path.join(os.getcwd(), "database_ff")

    if not os.path.exists(database_dir):
        print("❌ Error: The folder 'database_ff' does not exist.")
        return []

    files = [f for f in os.listdir(database_dir) if f.endswith(".in")]
    coppie_elementi = []

    for file in files:
        nome = file.replace(".in", "")
        if len(nome) >= 2:  # Controllo minimo sulla lunghezza
            # Estrai gli elementi dalla stringa (primi caratteri maiuscoli sono elementi)
            atomi = []
            buffer = ""

            for char in nome:
                if char.isupper() and buffer:  # Se trovi una maiuscola e hai già un atomo
                    atomi.append(buffer)  # Aggiungi l'atomo precedente alla lista
                    buffer = char  # Inizia un nuovo atomo
                else:
                    buffer += char  # Continua a costruire il nome dell'atomo

            atomi.append(buffer)  # Aggiunge l'ultimo atomo trovato

            if len(atomi) == 2:  # Se ha trovato esattamente due atomi, è valido
                coppie_elementi.append(f"{atomi[0]}{atomi[1]}")

    return sorted(coppie_elementi)  # Ordina alfabeticamente

# ✅ Funzione per avviare la GUI Tkinter
def avvia_interfaccia_grafica():

    elementi_database = carica_elementi_da_database()
    
    if not elementi_database:
        messagebox.showerror("Error", "No valid file found in 'database_ff'.")
        sys.exit(1)

    def aggiorna_atomi(event):
        selezione = combo_elementi.get() 
        entry_atom1.set(selezione[:2])  # I primi due caratteri sono Atom1
        entry_atom2.set(selezione[2:])  # Il resto è Atom2
    
    def mostra_help():
        help_window = tk.Toplevel(root)
        help_window.title("Help")
        help_window.geometry("900x300")
        tk.Label(help_window, text="[Couple of metals]: choose one of the metals couple in the folder database_ff.\n\
                 [Cluster dimension]: choose the size of the cluster.\n\
                 [Cluster start]: 0, suggest value.\n\
                 [Pruning]: choose the mesh to sweep composition range.\n\
                 [Nbh]: choose the desired number of BH steps. The following values are suggested: 10000 (for clusters composed by about 200 atoms) and 30000/50000 for clusters composed by 600/800 atoms.\n\
                 [Box dimension]: choose the random starting structure dimension. The following values are suggested: for a cluster of 200 atoms choose (-6 to +6); for a cluster of 800 atoms choose (-10 to +10).\
                 ").pack(pady=20)

    def salva_e_modifica(event=None):
        global atom1, atom2, size_end, size_start
        atom1 = entry_atom1.get()
        atom2 = entry_atom2.get()
        size_end = entry_size_end.get()
        size_start = entry_size_start.get()
        pruning = entry_pruning.get()
        nbh = entry_nbh.get()
        interval = entry_interval.get()
        
        if not all([atom1, atom2, size_end, size_start, pruning, nbh, interval]):
            messagebox.showwarning("Attention", "Fill in all fields!")
            return
        
        if not size_end.isdigit() or not size_start.isdigit() or not pruning.isdigit() or not nbh.isdigit() or not interval.isdigit():
            messagebox.showerror("Error", "Cluster dimension, Cluster start, Pruning, Nbh and Box dimension must contain only numbers!")
            return
        
        # Definizione della cartella originale e della nuova cartella
        old_folder_unseed = "parallel_unseeded_XxYy"
        new_folder_unseed = f"parallel_unseeded_{atom1}{atom2}"

        old_folder_seed = "parallel_seeded_XxYy"
        new_folder_seed = f"parallel_seeded_{atom1}{atom2}"
        
        # Lista dei file da modificare
        file_list = [
            "01_search_unbiased",
            f"{old_folder_unseed}/analize",
            f"{old_folder_unseed}/clean",
            f"{old_folder_unseed}/crea",
            f"{old_folder_unseed}/input_bh.in_0925",
            f"{old_folder_unseed}/input_bh.in_0950",
            f"{old_folder_unseed}/input_bh.in_0975",
            f"{old_folder_unseed}/input_bh.in_P",
            f"{old_folder_unseed}/parallel_unseeded.f90"
        ]
        
        for file_path in file_list:
            if os.path.exists(file_path):
                try:
                    with open(file_path, "r") as f:
                        content = f.read()
                    
                    content = content.replace("Xx", atom1)
                    content = content.replace("Yy", atom2)
                    content = content.replace("SizeEnd1", size_end)
                    content = content.replace("SizeStart1", size_start)
                    content = content.replace("Pruning1", pruning)
                    content = content.replace("nbh1", nbh)
                    
                    # Modifica specifica per parallel_unseeded.f90
                    if "parallel_unseeded.f90" in file_path:
                        content = re.sub(r"-6\.0, 6\.0 !", f"-{interval}.0, {interval}.0 !", content)
                        
                    
                    with open(file_path, "w") as f:
                        f.write(content)
                    
                except Exception as e:
                    messagebox.showerror("Error", f"Error in file {file_path}: {e}")
        
        if os.path.exists(old_folder_unseed):
            os.rename(old_folder_unseed, new_folder_unseed)

        if os.path.exists(old_folder_seed):
            os.rename(old_folder_seed, new_folder_seed)

        messagebox.showinfo("Success", "Files changed and folder renamed successfully!")
        root.destroy()

    # Creazione della finestra principale
    root = tk.Tk()
    root.title("Entering data")
    root.geometry("400x300")

    # Creazione dei frame per organizzare i campi
    frame_left = tk.Frame(root)
    frame_left.grid(row=0, column=0, padx=10, pady=10, sticky="nw")

    frame_right = tk.Frame(root)
    frame_right.grid(row=0, column=1, padx=10, pady=10, sticky="ne")

    # Dropdown per scegliere il file da database_ff
    tk.Label(frame_left, text="Couple of metals:").grid(row=0, column=0, sticky="w")
    combo_elementi = ttk.Combobox(frame_left, values=elementi_database, state="readonly")
    combo_elementi.grid(row=1, column=0, sticky="w")
    combo_elementi.bind("<<ComboboxSelected>>", aggiorna_atomi)

    # Campi di input (aggiornati automaticamente)
    entry_atom1 = tk.StringVar()
    entry_atom2 = tk.StringVar()

    tk.Label(frame_left, text="Atom1:").grid(row=2, column=0, sticky="w")
    tk.Entry(frame_left, textvariable=entry_atom1, state="readonly").grid(row=3, column=0, sticky="w")

    tk.Label(frame_left, text="Atom2:").grid(row=4, column=0, sticky="w")
    tk.Entry(frame_left, textvariable=entry_atom2, state="readonly").grid(row=5, column=0, sticky="w")

    tk.Label(frame_right, text="Cluster dimension:").grid(row=0, column=0, sticky="w")
    entry_size_end = tk.Entry(frame_right)
    entry_size_end.grid(row=1, column=0, sticky="w")

    tk.Label(frame_right, text="Cluster start:").grid(row=2, column=0, sticky="w")
    entry_size_start = tk.Entry(frame_right)
    entry_size_start.grid(row=3, column=0, sticky="w")

    tk.Label(frame_right, text="Pruning:").grid(row=4, column=0, sticky="w")
    entry_pruning = tk.Entry(frame_right)
    entry_pruning.grid(row=5, column=0, sticky="w")

    tk.Label(frame_right, text="Nbh:").grid(row=6, column=0, sticky="w")
    entry_nbh = tk.Entry(frame_right)
    entry_nbh.grid(row=7, column=0, sticky="w")

    tk.Label(frame_right, text="Box dimension:").grid(row=8, column=0, sticky="w")
    entry_interval = tk.Entry(frame_right)
    entry_interval.grid(row=9, column=0, sticky="w")

    # Pulsanti
    frame_buttons = tk.Frame(root)
    frame_buttons.grid(row=1, column=0, columnspan=2, pady=10)

    # Pulsante per salvare e modificare i file e chiedere Help
    tk.Button(frame_buttons, text="Save", command=salva_e_modifica).grid(row=0, column=0, padx=10)
    tk.Button(frame_buttons, text="Help", command=mostra_help).grid(row=0, column=1, padx=10, sticky="e")

    # Associa il tasto Invio alla funzione salva_e_modifica
    root.bind("<Return>", salva_e_modifica)

    root.mainloop()

    modify_identify_pures()
    command_list2()
    biased_part()
    command_list3()

def command_list2():
    try:
        print("🔹 Start script2...")

        # Definizione delle cartelle
        base_dir = os.getcwd()
        unseed_dir = os.path.join(base_dir, f"parallel_unseeded_{atom1}{atom2}")
        seed_dir = os.path.join(base_dir, f"parallel_seeded_{atom1}{atom2}")
        database_dir = os.path.join(base_dir, "database_ff")
        file_XxYy_in = f"{atom1}{atom2}.in"

        # 🔹 Copiare il file XxYy.in nella cartella parallel_unseeded_XxYy
        source_file = os.path.join(database_dir, file_XxYy_in)
        destination_file = os.path.join(unseed_dir, file_XxYy_in)
        destination_file2 = os.path.join(seed_dir, file_XxYy_in)

        print(f"🔹 Copying {file_XxYy_in} in {unseed_dir}...")
        subprocess.run(["cp", source_file, destination_file], check=True)
        print(f"🔹 Copying {file_XxYy_in} in {seed_dir}...")
        subprocess.run(["cp", source_file, destination_file2], check=True)

        base_dir = os.getcwd()  # Prende la cartella corrente
        parallel_unseeded_dir = os.path.join(base_dir, f"parallel_unseeded_{atom1}{atom2}")

        compile_parallel_unseeded = ["gfortran", "-o", "parallel_unseeded.x", "parallel_unseeded.f90"]
        compile_read = ["gfortran", "-o", "read.x", "read.f90"]
        compile_search_unbiased = ["chmod", "a+x", "01_search_unbiased"]
        compile_identify_pures = ["chmod", "a+x", "021_identify_pures"]
        compile_analize = ["chmod", "a+x", "analize"]
        compile_crea = ["chmod", "a+x", "crea"]
        compile_clean = ["chmod", "a+x", "clean"]
        run_identify_pures = ["./021_identify_pures"]
        compile_022_take = ["gfortran", "-o", "022_take.x", "022_take.f90"]
        run_022_take = ["./022_take.x"]
        run_023_copy = ["./023_copy.sh"]
        compile_search_unbiasedREV = ["chmod", "a+x", "024_search_unbiased.REVISE"]
        run_search_unbiasedREV = ["./024_search_unbiased.REVISE"]
        compile_02_best = ["gfortran", "-o", "02_best.x", "02_best.f90"]
        compile_03_take = ["gfortran", "-o", "03_take.x", "03_take.f90"]
        run_02_best = ["./02_best.x"]
        run_03_take = ["./03_take.x"]
        run_04_extract = ["./04_extract.sh"]

        print("🔹 Compiling parallel_unseeded.x ...")
        subprocess.run(compile_parallel_unseeded, cwd=parallel_unseeded_dir, check=True)
        print("🔹 Compiling analize ...")
        subprocess.run(compile_analize, cwd=parallel_unseeded_dir, check=True)
        print("🔹 Compiling clean ...")
        subprocess.run(compile_clean, cwd=parallel_unseeded_dir, check=True)
        print("🔹 Compiling crea ...")
        subprocess.run(compile_crea, cwd=parallel_unseeded_dir, check=True)
        print("🔹 Compiling read.x ...")
        subprocess.run(compile_read, cwd=parallel_unseeded_dir, check=True)
        print("🔹 Running 01_search_unbiased ...")
        subprocess.run(compile_search_unbiased, cwd=base_dir, check=True)
        # Avvia il processo SENZA &, in modo che Python lo gestisca direttamente
        with open(os.path.join(base_dir, "LOG_U"), "w") as log_file:
            process01 = subprocess.Popen(
                ["nohup", "./01_search_unbiased"],
                cwd=base_dir,
                stdin=subprocess.DEVNULL,
                stdout=log_file,
                stderr=subprocess.STDOUT
            )

        # Aspetta la terminazione effettiva del processo
        process01.wait()

        print("🔹 End 01_search_unbiased")
        print("🔹 Running 021_identify_pures ...")
        subprocess.run(compile_identify_pures, cwd=base_dir, check=True)
        subprocess.run(run_identify_pures, cwd=base_dir, check=True)
        print("🔹 Running 022_take ...")
        subprocess.run(compile_022_take, cwd=base_dir, check=True)
        subprocess.run(run_022_take, cwd=base_dir, check=True)
        print("🔹 Running 023_copy.sh ...")
        subprocess.run(run_023_copy, cwd=base_dir, check=True)
        print("🔹 Running 024_search_unbiased.REVISE ...")
        subprocess.run(compile_search_unbiasedREV, cwd=base_dir, check=True)
        subprocess.run(run_search_unbiasedREV, cwd=base_dir, check=True)
        print("🔹 Running 02_best ...")
        subprocess.run(compile_02_best, cwd=base_dir, check=True)
        subprocess.run(run_02_best, cwd=base_dir, check=True)
        print("🔹 Running 03_take ...")
        subprocess.run(compile_03_take, cwd=base_dir, check=True)
        subprocess.run(run_03_take, cwd=base_dir, check=True)
        print("🔹 Running 04_extract.sh ...")
        subprocess.run(run_04_extract, cwd=base_dir, check=True)

        print("✅ End script2!")

    except subprocess.CalledProcessError as e:
        print(f"❌ Error while executing a command: {e}")
        sys.exit(1)
    except FileNotFoundError as e:
        print(f"❌ Error: File or directory not found: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

def format_number(value):
    """Formatta un numero intero in una stringa a 4 cifre con zeri iniziali."""
    return f"{int(value):04d}"

def modify_identify_pures():
    """Modifica i file 021_identify_pures e 024_search_unbiased.REVISE sostituendo i placeholder con i valori corretti."""
    print("✅ Start script3!")
    try:
        base_dir = os.getcwd()
        files_to_modify = [
            os.path.join(base_dir, "021_identify_pures"),
            os.path.join(base_dir, "024_search_unbiased.REVISE")
        ]

        for file_path in files_to_modify:
            if not os.path.exists(file_path):
                print(f"❌ Error: {file_path} file not found.")
                continue
            else:
                print(f"✅ File {file_path} found.")
                
        
            with open(file_path, "r") as f:
                content = f.read()

                formatted_size_start = format_number(size_start)
                formatted_size_end = format_number(size_end)

                content = content.replace("Xx", atom1)
                content = content.replace("Yy", atom2)
                content = content.replace("'SizeStart1'", formatted_size_start)
                content = content.replace("'SizeEnd1'", formatted_size_end)
                content = content.replace("rm -r ./run 0000", "rm -r ./run_0000")

            with open(file_path, "w") as f:
                f.write(content)

        print(f"✅ File {file_path} modified successfully!")
    except Exception as e:
        print(f"❌ Error while modifying files: {e}")
    
    print("✅ End script3!")

def biased_part():

    print("🔹 Start Biased_edit...")

    def apri_finestra_biased():
        """Apre una nuova finestra per inserire i dati della seconda parte."""

        def salva_biased2():
            
            global size_start2, size_end2, pruning2, nbh2
            size_start2 = entry_size_start2.get()
            size_end2 = entry_size_end2.get()
            pruning2 = entry_pruning2.get()
            nbh2 = entry_nbh2.get()
            messagebox.showinfo("Success", "Dati validi e registrati correttamente!")
            biased_window.destroy()
            root.destroy()

            folder_seed = f"parallel_seeded_{atom1}{atom2}"

            formatted_size_start = format_number(size_start)
            formatted_size_end = format_number(size_end)

            file_list_seed = [
                "05_search_biased",
                f"{folder_seed}/analize",
                f"{folder_seed}/clean",
                f"{folder_seed}/crea",
                f"{folder_seed}/input_bh.in",
                f"{folder_seed}/parallel_seeded.f90",
            ]

            for file_path in file_list_seed:
                if os.path.exists(file_path):
                    try:
                        with open(file_path, "r") as f:
                            content = f.read()
                    
                        content = content.replace("Xx", atom1)
                        content = content.replace("Yy", atom2)
                        content = content.replace("SizeEnd2", size_end2)
                        content = content.replace("SizeStart2", size_start2)
                        content = content.replace("Pruning2", pruning2)
                        content = content.replace("nbh2", nbh2)
                        content = content.replace("'SizeEnd1'", formatted_size_end)
                        content = content.replace("'SizeStart1'", formatted_size_start)
                        
                        with open(file_path, "w") as f:
                            f.write(content)
                    
                    except Exception as e:
                        messagebox.showerror("Error", f"Error in file {file_path}: {e}")
        


            messagebox.showinfo("Success", "Files changed and folder renamed successfully!")
            root.destroy()
            
            
        
        
        biased_window = tk.Toplevel(root)
        biased_window.title("Biased Input")
        biased_window.geometry("300x250")
        
        tk.Label(biased_window, text="Size Start 2:").pack()
        entry_size_start2 = tk.Entry(biased_window)
        entry_size_start2.pack()
        
        tk.Label(biased_window, text="Size End 2:").pack()
        entry_size_end2 = tk.Entry(biased_window)
        entry_size_end2.pack()
        
        tk.Label(biased_window, text="Pruning 2:").pack()
        entry_pruning2 = tk.Entry(biased_window)
        entry_pruning2.pack()
        
        tk.Label(biased_window, text="Nbh 2:").pack()
        entry_nbh2 = tk.Entry(biased_window)
        entry_nbh2.pack()
        
        tk.Button(biased_window, text="Submit", command=salva_biased2).pack(pady=10)
        biased_window.bind("<Return>", salva_biased2)

    # Creazione della finestra principale
    root = tk.Tk()
    root.title("Main Interface")
    root.geometry("400x200")

    tk.Label(root, text="Vuoi continuare con la seconda parte (biased)?").pack(pady=20)

    tk.Button(root, text="Sì", command=apri_finestra_biased).pack(side=tk.LEFT, padx=20)
    tk.Button(root, text="No", command=root.quit).pack(side=tk.RIGHT, padx=20)
    

    root.mainloop()

    print("🔹 End Biased_edit...")

def command_list3():

    print("🔹 Start script3...")

    base_dir = os.getcwd()
    seed_dir = os.path.join(base_dir, f"parallel_seeded_{atom1}{atom2}")

    compile_search_biased = ["chmod", "a+x", "05_search_biased"]
    compile_analize = ["chmod", "a+x", "analize"]
    compile_crea = ["chmod", "a+x", "crea"]
    compile_clean = ["chmod", "a+x", "clean"]
    compile_parallel_seeded = ["gfortran", "-o", "parallel_seeded.x", "parallel_seeded.f90"]
    compile_read = ["gfortran", "-o", "read.x", "read.f90"]
    compile_best = ["gfortran", "-o", "06_best.x", "06_best.f90"]
    compile_take = ["gfortran", "-o", "07_take.x", "07_take.f90"]
    
    run_best = ["./06_best.x"]
    run_take = ["./07_take.x"]
    run_extract = ["./08_extract.sh"]

    print("🔹 Compiling 05_search_biased ...")
    
    print("🔹 Compiling analize ...")
    subprocess.run(compile_analize, cwd=seed_dir, check=True)
    print("🔹 Compiling clean ...")
    subprocess.run(compile_clean, cwd=seed_dir, check=True)
    print("🔹 Compiling crea ...")
    subprocess.run(compile_crea, cwd=seed_dir, check=True)
    print("🔹 Compiling parallel_seeded.x ...")
    subprocess.run(compile_parallel_seeded, cwd=seed_dir, check=True)
    print("🔹 Compiling read.x ...")
    subprocess.run(compile_read, cwd=seed_dir, check=True)
    print("🔹 Compiling 06_best.x ...")
    subprocess.run(compile_best, cwd=base_dir, check=True)
    print("🔹 Compiling 07_take.x ...")
    subprocess.run(compile_take, cwd=base_dir, check=True)

    print("🔹 Running 05_search_biased ...")
    subprocess.run(compile_search_biased, cwd=base_dir, check=True)
    
    # Avvia il processo SENZA &, in modo che Python lo gestisca direttamente
    with open(os.path.join(base_dir, "LOG_U"), "w") as log_file:
        process05 = subprocess.Popen(
            ["nohup", "./05_search_biased"],
            cwd=base_dir,
            stdin=subprocess.DEVNULL,
            stdout=log_file,
            stderr=subprocess.STDOUT
        )

    # Aspetta la terminazione effettiva del processo
    process05.wait()

    print("🔹 End 05_search_biased")

    print("🔹 Running 06_best.x ...")
    subprocess.run(run_best, cwd=base_dir, check=True)
    print("🔹 Running 07_take.x ...")
    subprocess.run(run_take, cwd=base_dir, check=True)
    print("🔹 Running 08_extract.sh ...")
    subprocess.run(run_extract, cwd=base_dir, check=True)
    
    print("🔹 Fine script BIASED ...")



if __name__ == "__main__":
    esegui_make_e_copia()
    avvia_interfaccia_grafica()
    