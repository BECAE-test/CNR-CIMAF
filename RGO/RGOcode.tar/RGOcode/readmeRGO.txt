### WARNING: The commands used for the pre-installation script (Step 1) are tailored for Ubuntu-based systems. If you are using a different Linux distribution or another operating system, you may need to adapt them accordingly.

### Step-by-Step Guide to Compile and Run RGO code

All the following commands must be executed in a Bash terminal.


#### Step 0: Extract "RGOcode"

0.1 Extract "RGOcode" by running the command:
	tar -xzf RGOcode.tar
	
	
#### Step 1: Run the Pre-Installation Script (Only Required the First Time)

1.1 Open a terminal and navigate into the extracted directory "RGOcode" where "pre-install.sh" is located.

1.2 If the script is not executable, make it executable by running the command:
	chmod a+x pre-install.sh

1.3 Run the command:
	./pre-install.sh
	
1.4 Activate the virtual environment created during installation:
	source .venv/bin/activate


#### Step 2: Select the Working Directory

2.1 In the same folder, run the "RGO" code by executing:
	python3 dijkstra.py
	
2.2 A window will appear asking you to select the folder where you want to work.
	
2.3 To choose the desired directory, double-click on the folder and press OK.


#### Step 3: Assign Names to Structure IDs (Optional)

3.1 A window will appear allowing you to assign custom names to structure IDs.

3.2 Press "Add" to insert a new assignment, the association will appear under "Current assignment".

3.3 To remove an existing assignment, select it and press "Remove".

3.4 When finished, press "End".

NOTE: This step is optional. The code works even without assigning names.


#### Step 4: Select Initial and Final Structures

4.1 Insert the initial and final structures for which you want to compute the minimum-energy path. You may enter either the numerical ID or the custom name assigned in Step 2.

4.2 Press "Calculate Path" to continue.


#### Step 5: Display the Calculated Path

5.1 A new window will appear showing the path identified by the algorithm.

5.2 Press the button to plot the calculated path.


#### Step 6: Visualize the Path Graph

6.1 After pressing "Plot", the graph of the minimum-energy path will be displayed.

6.2 Click on any point of the graph to view a popup window showing the characteristics of the selected structure.


#### Step 7: Visualize the Path Graph

7.1 Each popup window contains a button to open the .xyz file associated with the selected graph point.

7.2 Pressing the button will launch XCrySDen and display the corresponding structure.

NOTE: XCrySDen must be installed on your system for this functionality to work properly.


#### Step 8: Deactivate virtual environment

8.1 To deactivate virtual environment execute:
	deactivate
