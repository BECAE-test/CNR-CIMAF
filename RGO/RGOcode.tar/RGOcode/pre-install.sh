echo "Start script"

sudo apt install unrar -y

sudo apt install python3 -y

sudo apt install python3-pip -y

sudo apt install python3-tk -y

sudo apt install python3.10-venv -y

python3 -m venv .venv

source .venv/bin/activate

python -m pip install --upgrade pip

python -m pip install -r requirements.txt

deactivate

echo "End script"
