import math
import numpy as np
from scipy.sparse.csgraph import dijkstra
from scipy.sparse.csgraph import shortest_path
from scipy.sparse import csr_matrix
import tkinter as tk
from tkinter import messagebox, filedialog
import os
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
import shutil
import subprocess
import re

  
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR_NAME = filedialog.askdirectory(title="Select RGO working directory")
BASE_DIR = os.path.join(SCRIPT_DIR, BASE_DIR_NAME)

if not os.path.isdir(BASE_DIR):
    alt = os.path.join(os.getcwd(), BASE_DIR_NAME)
    if os.path.isdir(alt):
        BASE_DIR = alt
    else:
        print("[!] folder not found; CWD will be used.")
        BASE_DIR = "."
        
print("[i] BASE_DIR for .xyz:", BASE_DIR)

custom_names = {}

def build_sortstruct_from_structure_file(
    base_dir: str = BASE_DIR,
    structure_fname: str = "Structure_file.txt",
    out_fname: str = "sortstruct",
) -> str:
    """
    Read RGO_example/Structure_file.txt, sort for ID (2nd column) and write RGO/sortstruct.
    Return the path of sorted file.
    """
    import os

    src_path = os.path.join(base_dir, structure_fname)
    if not os.path.isfile(src_path):
        raise FileNotFoundError(f"File not found: {src_path}")

    sibling_root = os.path.dirname(base_dir)
    dst_path = os.path.join(sibling_root, out_fname)

    valid_rows = []     # (id_int, original_line)
    other_rows = []     # unparsable lines/to be left at the top

    with open(src_path, "r") as f:
        for raw in f:
            line = raw.rstrip("\n")
            strip = line.strip()
            if not strip or strip.startswith("#"):
                other_rows.append(line)
                continue

            parts = strip.split()
            
            if len(parts) < 2:
                other_rows.append(line)
                continue

            # try to identify ID from the 2nd column
            try:
                id_val = int(parts[1])
            except ValueError:
                # if 2nd column is not an int, consider as "other raws"
                other_rows.append(line)
                continue

            valid_rows.append((id_val, line))

    # sort by ascending ID (sort stabile)
    valid_rows.sort(key=lambda t: t[0])

    with open(dst_path, "w") as g:
        # First, write the ‘other lines’ in their original order
        for r in other_rows:
            g.write(r + "\n")
        # Then sorted lines by ID
        for _, r in valid_rows:
            g.write(r + "\n")

    print(f"[✓] sortstruct created: {dst_path}  (sorted lines: {len(valid_rows)}, other lines: {len(other_rows)})")
    return dst_path

def create_name_map(base_dir=BASE_DIR, data_fname="data.lammps", out_fname="name_map.txt"):

    data_path = os.path.join(base_dir, data_fname)
    out_path = os.path.join(base_dir, out_fname)

    if not os.path.isfile(data_path):
        raise FileNotFoundError(f"File not found: {data_path}")
    
    elements = read_elements_from_in(base_dir)
    
    pairs = []
    in_atoms = False

    with open(data_path, "r") as f:
        for raw in f:
            line = raw.strip()

            if not line or line.startswith("#"):
                continue

            if not in_atoms and line.lower().startswith("atoms"):
                in_atoms = True
                continue

            if in_atoms:
                if line[0].isalpha():
                    break

                parts = line.split()

                if len(parts) >= 2:
                    if parts[0].lstrip("-").isdigit() and parts[1].lstrip("-").isdigit():
                        pairs.append(f"{parts[0]} {parts[1]}")
                    else:
                        break

    if not pairs:
        raise ValueError("Section 'Atoms' not found or with unuseless data")
    
    with open(out_path, "w") as g:
        if elements:
            g.write(" ".join(elements) + "\n")
        g.write("\n".join(pairs) + "\n")

    return out_path

def resolve_name_map(base_dir=BASE_DIR, fname="name_map.txt", keep_header=True):

    path = os.path.join(base_dir, fname)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"File not found: {path}")
    
    with open(path, "r") as f:
        lines = [ln.strip() for ln in f if ln.strip()]

    if not lines:
        raise ValueError("Empty file")

    elements = lines[0].split()
    if not elements:
        raise ValueError("First raw without elements")

    out_lines = []
    if keep_header:
        out_lines.append(" ".join(elements))

    for ln in lines[1:]:
        parts = ln.split()
        if len(parts) < 2:
            continue
        atom_id = parts[0]
        try:
            idx = int(parts[1])
        except ValueError:
            raise ValueError(f"Invalid index: {ln}")

        if not (1 <= idx <= len(elements)):
            raise ValueError(f"Index out of range ({idx}) in raw: {ln}")
        
        out_lines.append(f"{atom_id} {elements[idx-1]}")

    with open(path, "w") as f:
        f.write("\n".join(out_lines) + "\n")

def read_elements_from_in(base_dir=BASE_DIR, in_fname="in.lammps"):
    in_path = os.path.join(base_dir, in_fname)
    if not os.path.isfile(in_path):
        return []

    elems = []
    with open(in_path, "r") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.lower().startswith("pair_coeff"):
                tokens = line.split()[1:]
                for t in tokens:
                    if t == "*":
                        continue
                    if re.fullmatch(r"[A-Za-z]+", t):
                        elems.append(t)
                break
    seen = set()
    elems_unique = [e for e in elems if not (e in seen or seen.add(e))]
    return elems_unique  

def read_elements_from_name_map(base_dir=BASE_DIR, fname="name_map.txt"):
    import os
    path = os.path.join(base_dir, fname)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"File not found: {path}")

    with open(path, "r") as f:
        lines = [ln.strip() for ln in f if ln.strip()]

    if not lines:
        raise ValueError("name_map.txt empty")


    data_lines = lines[1:]
    elements = []
    for ln in data_lines:
        parts = ln.split()
        if len(parts) >= 2:
            elements.append(parts[1])

    if not elements:
        raise ValueError("No elements found in the second raw of the name_map.txt")

    return elements  # len == m


    # """
    # Modifica IN-PLACE xyz_plot_path in modo *strict*:
    #   - per ciascun blocco (riga header che contiene 'LM'), sostituisce la colonna 'LM'
    #     nelle *successive m righe esatte* (m = len(elements_list)), senza saltare righe.
    #   - non prova ad “adattarsi” a righe vuote o formati strani: se non ci sono abbastanza
    #     righe, alza un errore e non continua sul blocco successivo.
    # """
    # import os
    # if not os.path.isfile(xyz_plot_path):
    #     raise FileNotFoundError(f"XYZ non trovato: {xyz_plot_path}")

    # m = len(elements_list)

    # with open(xyz_plot_path, "r") as f:
    #     lines = f.readlines()

    # n = len(lines)
    # i = 0
    # patched_blocks = 0

    # while i < n and patched_blocks < expected_blocks:
    #     line = lines[i]
    #     tokens = line.strip().split()

    #     # cerca header di blocco che contenga 'LM'
    #     if "LM" in tokens:
    #         lm_idx = tokens.index("LM")
    #         start = i + 1
    #         end = start + m

    #         if end > n:
    #             raise ValueError(
    #                 f"Blocco #{patched_blocks+1}: attese {m} righe dati dopo l'header 'LM' "
    #                 f"ma il file finisce a riga {n}. (start={start}, end={end})"
    #             )

    #         # patcha le *prossime m righe esatte*
    #         for row_idx in range(m):
    #             j = start + row_idx
    #             parts = lines[j].rstrip("\n").split()

    #             if len(parts) <= lm_idx:
    #                 raise ValueError(
    #                     f"Blocco #{patched_blocks+1}, riga {j+1}: "
    #                     f"la riga ha solo {len(parts)} colonne, non posso sostituire indice {lm_idx}."
    #                 )

    #             parts[lm_idx] = elements_list[row_idx]
    #             lines[j] = " ".join(parts) + "\n"

    #         patched_blocks += 1
    #         i = end  # salta direttamente oltre il blocco
    #         continue

    #     # non è un header: passa alla riga successiva
    #     i += 1

    # with open(xyz_plot_path, "w") as f:
    #     f.writelines(lines)

    # print(f"[✓] Colonne LM sostituite: {patched_blocks}/{expected_blocks} blocchi (strict)")

def replace_LM_blocks_using_count(xyz_plot_path, elements_list, expected_blocks=3):
    """
    Modify xyz_plot_path IN PLACE:
    block pattern:
        line i:         m (integer, equal to len(elements_list))
        line i+1:       4 numbers (left unchanged)
        lines i+2..:    m lines starting with 'LM' followed by 3 values
    Replace the 'LM' in column 1 with elements_list[k] for k = 0..m-1.
    Repeat for 'expected_blocks' blocks (typically 3).
    """
    import os
    if not os.path.isfile(xyz_plot_path):
        raise FileNotFoundError(f"XYZ not found: {xyz_plot_path}")

    m = len(elements_list)

    with open(xyz_plot_path, "r") as f:
        lines = f.readlines()

    n = len(lines)
    i = 0
    patched = 0

    def _looks_like_energy_line(s: str) -> bool:
        
        toks = s.strip().split()
        if not (3 <= len(toks) <= 5):
            return False
        for t in toks:
            try:
                float(t)
            except ValueError:
                return False
        return True

    while i < n and patched < expected_blocks:
        s = lines[i].strip()
        if s.isdigit() and int(s) == m and i + 1 < n and _looks_like_energy_line(lines[i + 1]):
            # verify that there are m lines and that each starts with 'LM'
            start = i + 2
            end = start + m
            if end > n:
                raise ValueError(f"Block #{patched+1}: expected {m} lines following the count line {i+1}, file too short.")

            ok = True
            for k in range(m):
                if not lines[start + k].lstrip().startswith("LM"):
                    ok = False
                    break

            if ok:
                # patch exactly m lines: replace first token 'LM' with corrsponding element
                for k in range(m):
                    j = start + k
                    parts = lines[j].rstrip("\n").split()
                    # guaranteed that parts[0] exists and equals 'LM'
                    parts[0] = elements_list[k]
                    lines[j] = " ".join(parts) + "\n"

                patched += 1
                i = end  # skip to the beginning of the next block
                continue
            # if it's not a valid block, continue scanning
        i += 1

    with open(xyz_plot_path, "w") as f:
        f.writelines(lines)

    print(f"[✓] Patch LM→elements completed on {patched}/{expected_blocks} blocks")

def name_for_id(sid: int) -> str:
    """Return 'ID (Name)' if present, otherwise 'ID'."""
    nm = custom_names.get(sid)
    return f"{nm} ({sid})" if nm else str(sid)
    

def open_xyz_linux(xyz_path: str):
    if not xyz_path:
        messagebox.showwarning("XCrySDen", "No file .xyz selected.")
        return
    if not os.path.isfile(xyz_path):
        messagebox.showerror("XCrySDen", f"File not found:\n{xyz_path}")
        return
        
    exe = shutil.which("xcrysden")
    if not exe:
        messagebox.showerror(
            "XCrySDen",
            "Command 'xcrysden' not found.\n"
            "Install with:\n\n sudo apt update && sudo apt install xcrysden"
        )
        return
        
    try:
        env = os.environ.copy()
        workdir = os.path.dirname(os.path.abspath(xyz_path))
        subprocess.Popen([exe, "--xyz", xyz_path], cwd=workdir, env=env)
    except Exception as e:
        messagebox.showerror("XCrySDen", f"Error during opening:\n{e}")
        
def find_xyz_for_transition(current_id: int, next_id: int, base_dir: str = "."):
    """
    Search for the .xyz file corresponding to the transition current_id -> next_id.

    Rules:
      - enter in Str_<current_id (32-character)>/candidatesort
      - select the candidate whose descriptor vector is closest to that of next_id.
      - inside the subfolder <best_id (32-character)>, look for a .xyz file (if multiple are present, choose the largest one by size).
    """
    # 1) folder of current structure
    str_folder = os.path.join(base_dir, f"Str_{to_32_digit(current_id)}")
    if not os.path.isdir(str_folder):
        return None, f"[!] Cartella non trovata: {str_folder}"

    # 2) file candidatesort
    cand_path = os.path.join(str_folder, "candidatesort")
    if not os.path.isfile(cand_path):
        return None, f"[!] File non trovato: {cand_path}"

    # 3) descriptors target: taken from next_id sortstruct line
    line_next = by_id.get(next_id)
    if line_next is None:
        return None, f"[!] ID {next_id} not present in sortstruct"
    parts_next = line_next.split()
    try:
        target_descr = list(map(float, parts_next[2:6]))
    except Exception:
        return None, f"[!] Impossible reading descriptors for ID {next_id}"

    # 4) scan candidatesort and find best match
    best_id, best_dist = None, float("inf")
    with open(cand_path, "r") as f:
        for ln in f:
            p = ln.strip().split()
            if len(p) < 6:
                continue
            try:
                cand_id = int(p[1])
                cand_descr = list(map(float, p[2:6]))
            except Exception:
                continue
            # euclidean distance
            dist = math.dist(cand_descr, target_descr)
            if dist < best_dist:
                best_dist, best_id = dist, cand_id

    if best_id is None:
        return None, "[!] No valid candidate in candidatesort"

    # 5) best match subfolder and research of .xyz (also recursively)
    sub = os.path.join(str_folder, to_32_digit(best_id))
    if not os.path.isdir(sub):
        return None, f"[!] Subfolder not found: {sub}"

    xyz_candidates = []
    for root, _, files in os.walk(sub):
        for fn in files:
            if fn.lower().endswith(".xyz"):
                xyz_candidates.append(os.path.join(root, fn))

    if not xyz_candidates:
        return None, f"[!] No .xyz found in: {sub}"

    # scegli quello più "corposo" (di solito è quello giusto)
    best_xyz = max(xyz_candidates, key=lambda p: os.path.getsize(p))
    rel = os.path.relpath(best_xyz)
    return best_xyz, f"[✓] .xyz: {rel}  | best_id={best_id}  dist={best_dist:.4g}"
    
def get_path(Pr, i, j):
    # caso banale
    if i == j:
        return [i]
    # nessun predecessore → nessun cammino
    if Pr[i, j] == -9999:
        return None
    path = [j]
    k = j
    # risali finché non arrivi alla sorgente i
    while k != i:
        k = Pr[i, k]
        if k == -9999:
            # cammino non ricostruibile
            return None
        path.append(k)
    return path[::-1]

def to_32_digit(n: int) -> str:
    return f"{int(n):032d}"    


try:
    outp = create_name_map(BASE_DIR)
    print(f"Created: {outp}")
except Exception as e:
    print(f"name_map.txt not created: {e}")


try:
    resolve_name_map(BASE_DIR)
    print("name_map.txt updated")
except Exception as e:
    print(f"Operation failed: {e}")


try:
    SORTSTRUCT_PATH = build_sortstruct_from_structure_file()
except Exception as e:
    # se fallisce, ripieghiamo su un path standard (o esci con errore)
    print(f"[!] Impossible create sortstruct: {e}")
    SORTSTRUCT_PATH = os.path.join(os.path.dirname(BASE_DIR), "RGO", "sortstruct")

with open("sortstruct") as sortato:
    lines = [line.rstrip() for line in sortato]

strnum=[]

for ii in range(len(lines)):
    templine = ' '.join(lines[ii].split())
    strnum.append(int(templine.split(' ')[1]))

strnums = strnum

id_to_idx = {v: i for i, v in enumerate(strnums)}

by_id = {}
for ln in lines:
    p = ' '.join(ln.split()).split(' ')
    by_id[int(p[1])] = ln

connect = np.zeros((len(lines),len(lines)))

for ii in range(len(lines)):
    templine = ' '.join(lines[ii].split())
    nvicini = int(templine.split(' ')[6])
    tempemin = float(templine.split(' ')[2])
    for ij in range(nvicini):
        tempidx = int(templine.split(' ')[ij+7])
        tempets = float(templine.split(' ')[ij+7+nvicini])
        temprate = math.exp(tempets-tempemin)
        connect[ii, id_to_idx[tempidx]] = temprate

newarr = csr_matrix(connect)

#Invoca il Dijkstra. La prima riga era per le distanze topologiche, la seconda per quelle energetiche.
#Come detto in precedenza, quelle energetiche non sono simmetriche, quindi il grafo è directed
#D sta per usa il metodo dijkstra
D, Pr = shortest_path(newarr, directed=True, method='D', return_predecessors=True)

def show_name_mapping_dialog(parent):
    dlg = tk.Toplevel(parent)
    dlg.title("Assign names to structures")
    dlg.transient(parent)
    dlg.resizable(False, False)

    # campi input
    tk.Label(dlg, text="Structure ID:").grid(row=0, column=0, padx=10, pady=(10,4), sticky="e")
    e_id = tk.Entry(dlg, width=10)
    e_id.grid(row=0, column=1, padx=10, pady=(10,4), sticky="w")

    tk.Label(dlg, text="Name:").grid(row=1, column=0, padx=10, pady=4, sticky="e")
    e_name = tk.Entry(dlg, width=18)
    e_name.grid(row=1, column=1, padx=10, pady=4, sticky="w")

    # lista visuale delle mappature
    tk.Label(dlg, text="Current assignment:").grid(row=2, column=0, columnspan=2, padx=10, pady=(8,4), sticky="w")
    lst = tk.Listbox(dlg, width=28, height=6)
    lst.grid(row=3, column=0, columnspan=2, padx=10, pady=(0,8), sticky="we")

    def refresh_list():
        lst.delete(0, tk.END)
        for k in sorted(custom_names.keys(), key=int):
            lst.insert(tk.END, f"{k} → {custom_names[k]}")

    def add_mapping():
        try:
            sid = int(e_id.get().strip())
        except ValueError:
            messagebox.showwarning("not valid ID", "Enter an integer fot the ID.")
            return
        if sid not in strnum:
            messagebox.showwarning("ID not present", f"ID {sid} is not present in the structures.")
            return
        nm = e_name.get().strip()
        if not nm:
            messagebox.showwarning("Empty name", "Enter a not-empty name.")
            return
        custom_names[sid] = nm
        e_id.delete(0, tk.END)
        e_name.delete(0, tk.END)
        refresh_list()

    def remove_selected():
        sel = lst.curselection()
        if not sel: return
        text = lst.get(sel[0])
        sid = int(text.split("→")[0].strip())
        custom_names.pop(sid, None)
        refresh_list()

    btn_frame = tk.Frame(dlg); btn_frame.grid(row=4, column=0, columnspan=2, pady=(6,10))
    tk.Button(btn_frame, text="Add", command=add_mapping).grid(row=0, column=0, padx=6)
    tk.Button(btn_frame, text="Remove", command=remove_selected).grid(row=0, column=1, padx=6)
    tk.Button(btn_frame, text="End", command=dlg.destroy).grid(row=0, column=2, padx=6)

    refresh_list()

    # modal
    dlg.update_idletasks()
    dlg.deiconify(); dlg.lift(); dlg.focus_force()
    try:
        dlg.grab_set()
    except tk.TclError:
        pass
    parent.wait_window(dlg)

def run_gui():

    def resolve_id_from_user(text: str) -> int:
        s = text.strip()
        if not s:
            raise ValueError("Empty field.")

        
        try:
            return int(s)
        except ValueError:
            pass

       
        
        name_to_id = {name.lower(): sid for sid, name in custom_names.items()}
        sid = name_to_id.get(s.lower())
        if sid is not None:
            return sid

        
        m = re.search(r"-?\d+", s)
        if m:
            return int(m.group(0))

        raise ValueError(f"'{text}' not a name or a valid ID.")

    
    def calcola_percorso():
        try:
            id_i = resolve_id_from_user(entry_i.get())
            id_j = resolve_id_from_user(entry_j.get())


            if id_i not in strnum or id_j not in strnum:
                raise ValueError("ID not present in the structure list")

            index_i = id_to_idx[id_i]
            index_j = id_to_idx[id_j]

            
            if np.isinf(D[index_i, index_j]):
                messagebox.showwarning("No path", "Path between selected ID doesn't exist.")
                return
            
            percorso_ids = get_path(Pr, index_i, index_j)
            if not percorso_ids:
                messagebox.showwarning("No path", "No path available.")
                return
            
            percorso_str = [strnum[p] for p in percorso_ids]
            open_result_window(percorso_str)


        except Exception as e:
            messagebox.showerror("Error", f"Error: {e}")

    def open_result_window(percorso_str):
        result_window = tk.Toplevel()

        ##
        fig_ref = {"fig": None} 

        def on_close_result():
            if fig_ref["fig"] is not None:
                plt.close(fig_ref["fig"])
            result_window.destroy()

        result_window.protocol("WM_DELETE_WINDOW", on_close_result)
        ##
        
        
        last_xyz = {"path": None}

        def show_point_details(msg: str):
            dlg = tk.Toplevel(result_window)
            
            windows_detail.append(dlg)
            
            dlg.title("Point detail")
            dlg.transient(result_window)
            
            
            dlg.update_idletasks()
            dlg.deiconify()
            dlg.lift()
            dlg.focus_force()

            
            try:
                dlg.wait_visibility()  
                dlg.grab_set()         
            except tk.TclError:
               
                dlg.after(50, lambda: dlg.grab_set())


            lbl = tk.Label(dlg, text=msg, justify="left", anchor="w", wraplength=520)
            lbl.pack(padx=12, pady=(12, 8), fill="x")

            btn_frame = tk.Frame(dlg)
            btn_frame.pack(padx=12, pady=(0, 12))

            btn_linux = tk.Button(
                btn_frame, text="Open in XCrySDen",
                state=("normal" if last_xyz["path"] else "disabled"),
                command=lambda: open_xyz_linux(last_xyz["path"]) if last_xyz["path"] else None
            )
            btn_linux.grid(row=0, column=0, padx=6)

            def on_close_dig():
                if dlg in windows_detail:
                    windows_detail.remove(dlg)
                
                if last_xyz.get("path") and last_xyz["path"].endswith("_plot.xyz"):
                    try:
                        os.remove(last_xyz["path"])
                        print(f"Temporary file deleted: {last_xyz['path']}")
                    except Exception as e:
                        print(f"Not possible to delete {last_xyz['path']}: {e}")

                dlg.destroy()

            
            tk.Button(dlg, text="Close", command=on_close_dig).pack(pady=(0, 10))

            dlg.protocol("WM_DELETE_WINDOW", on_close_dig)
            
            
        result_window.title("Path")

       
        path_display = ' → '.join(name_for_id(p) for p in percorso_str)
        tk.Label(result_window, text="Path with lowest energy:", font=("Helvetica", 12, "bold")).pack(padx=10, pady=(10, 2))
        tk.Label(result_window, text=path_display, wraplength=400).pack(padx=10, pady=(0, 10))

        ##
        windows_detail = [] 
        ##

        def plot_energy():
            energies = []
            labels = []
            extra_info = []

            for idx, struct_id in enumerate(percorso_str):
                parts = by_id[struct_id].split()
                energy = float(parts[2])            # column 3
                descriptors = parts[3:6]             # column 4,5,6
                energies.append(energy)
                
                labels.append(name_for_id(struct_id))
                extra_info.append({
                    "type": "structure",
                    "id": struct_id,
                    "energy": energy,
                    "descriptors": descriptors
                })

                if idx < len(percorso_str) - 1:
                    next_id = percorso_str[idx + 1]
                    nvicini = int(parts[6])
                    vicini = list(map(int, parts[7:7 + nvicini]))
                    barriere = list(map(float, parts[7 + nvicini:7 + 2 * nvicini]))
                    if next_id in vicini:
                        barrier_idx = vicini.index(next_id)
                        energia_sella = barriere[barrier_idx]
                        energies.append(energia_sella)
                        
                        labels.append(f"TS ({name_for_id(struct_id)}-{name_for_id(next_id)})")

                        extra_info.append({
                            "type": "sella",
                            "from": struct_id,
                            "to": next_id,
                            "energia": energia_sella,
                            "precedente_energia": energy 
                        })
                    else:
                        energies.append(np.nan)  
                        labels.append("???")
                        extra_info.append({"type": "unknown"})


            x = list(range(len(energies)))

            fig, ax = plt.subplots(figsize=(10, 5))
            ##
            fig_ref["fig"] = fig  
            ##
            def on_close_figure(event):
                for w in list(windows_detail):
                    try:
                        w.destroy()
                    except Exception:
                        pass
                windows_detail.clear()

            fig.canvas.mpl_connect("close_event", on_close_figure)


            ax.plot(range(len(energies)), energies, color='green', linestyle='-', linewidth=1)

            for i, info in enumerate(extra_info):
                if np.isnan(energies[i]):
                    continue
                if info['type'] == "struttura":
                    ax.plot(i, energies[i], marker='o', color='blue', markersize=8)
                elif info['type'] == "sella":
                    ax.plot(i, energies[i], marker='^', color='red', markersize=8)
                else:
                    ax.plot(i, energies[i], marker='x', color='gray', markersize=8)

            ax.set_xticks(list(range(len(labels))))
            ax.set_xticklabels(labels, rotation=45)

            ax.set_ylabel("Energy")
            ax.set_title("Path Energy Profile")
            ax.grid(True)
            plt.tight_layout()


            def on_click(event):
                if event.inaxes == ax:
                    x_click = round(event.xdata)
                    if 0 <= x_click < len(extra_info):
                        info = extra_info[x_click]
                        if info["type"] == "struttura":
                            msg = (
                                f"Structure ID: {name_for_id(info['id'])}"
                              
                                + "\n"
                                f"Descriptors: {info['descrittori'][0]}, {info['descrittori'][1]}, {info['descrittori'][2]}\n"
                                f"Energy: {info['energy']}"
                            )
                        elif info["type"] == "sella":
                            barriera = info['energy'] - info['precedente_energia']
                            msg = (
                                f"State transition: {info['from']} → {info['to']}\n"
                                f"Saddle energy: {info['energy']}\n"
                                f"Energy activation barrier: {barriera:.4f}"
                            )
                        else:
                            msg = "No info for this point."


                        try:
                            idx_corrente = x_click

                            if idx_corrente + 1 < len(extra_info):
                                next_info = extra_info[idx_corrente + 1]
                                if next_info["type"] == "sella" and next_info["from"] == info["id"]:
                                    current_id = info["id"]
                                    next_id = next_info["to"]
                                    
                                    xyz_path, debug_msg = find_xyz_for_transition(current_id, next_id, base_dir=BASE_DIR)
                                    print("[xyz]",debug_msg)
                                    xyz_plot_path = None
                                    if xyz_path and os.path.isfile(xyz_path):
                                        base, ext = os.path.splitext(xyz_path)
                                        xyz_plot_path = base + "_plot" + ext

                                        try:
                                            shutil.copy2(xyz_path, xyz_plot_path)
                                            print(f"[✓] Copied file .xyz in: {xyz_plot_path}")
                                        except Exception as e:
                                            print(f"[!] Error in teh copy of the file .xyz: {e}")

                                        try:
                                            elems = read_elements_from_name_map(BASE_DIR)  # lista di m elementi
                                            replace_LM_blocks_using_count(xyz_plot_path, elems, expected_blocks=3)
                                        except Exception as e:
                                            print(f"[!] Patch LM→elements failed in '{xyz_plot_path}': {e}")

                                    last_xyz["path"] = os.path.abspath(xyz_plot_path or xyz_path) if (xyz_plot_path or xyz_path) else None  

  
                                else:
                                    print("[i] No transiction from this structure.")
                            else:
                                print("[i] Last point of the path.")

                        except Exception as e:
                            print(f"[Error] During research of file .xyz: {e}")

                        
                        print("[Point detail]:", repr(msg))
                        result_window.after(0, lambda: show_point_details(msg))

            fig.canvas.mpl_connect("button_press_event", on_click)

            plt.show(block=False)

        tk.Button(result_window, text="Plot", command=plot_energy).pack(pady=5)

    root = tk.Tk()
    root.title("Path calculation between structures")
    show_name_mapping_dialog(root)

    tk.Label(root, text="Initial structure (ID):").grid(row=0, column=0, padx=10, pady=5)
    entry_i = tk.Entry(root)
    entry_i.grid(row=0, column=1, padx=10, pady=5)

    tk.Label(root, text="Final structure (ID):").grid(row=1, column=0, padx=10, pady=5)
    entry_j = tk.Entry(root)
    entry_j.grid(row=1, column=1, padx=10, pady=5)

    tk.Button(root, text="Calculate path", command=calcola_percorso).grid(row=2, column=0, columnspan=2, pady=10)

    root.mainloop()

run_gui() 

